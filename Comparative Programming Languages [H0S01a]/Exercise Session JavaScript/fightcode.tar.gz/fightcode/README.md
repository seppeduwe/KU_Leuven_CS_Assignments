FightCode
=========

To run this local copy of http://fightcodegame.com, open a terminal window

    cd /path/to/fightcode
    python -m SimpleHTTPServer 8888

Next, open a browser window and go to http://localhost:8888/fightcode.html
