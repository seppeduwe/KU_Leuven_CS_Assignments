package inheritance

object Multiple extends App {
  class A {
    def foo() = {
      println("A")
    }
  }

  trait B extends A {
    override def foo() = {
      println("B")
      super.foo()
    }
  }

  trait C extends B {
    override def foo() = {
      println("C")
      super.foo()
    }
  }

  trait D extends A {
    override def foo() = {
      println("D")
      super.foo()
    }
  }

  trait Stopper extends A {
    override def foo() = {
      println("Stop")
    }
  }

  val d = new A with B with C with D
  d.foo // prints D C B A

  println()

  val s = new A with B with Stopper with C with D
  s.foo // prints D C Stop
}
