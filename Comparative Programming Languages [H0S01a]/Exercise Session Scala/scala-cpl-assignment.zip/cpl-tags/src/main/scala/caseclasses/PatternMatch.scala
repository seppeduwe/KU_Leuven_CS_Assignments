package caseclasses

object PatternMatch extends App {
  trait Expr
  case class Number(num: Double) extends Expr
  case class Plus(left: Expr, right: Expr) extends Expr
  case class Min(left: Expr, right: Expr) extends Expr

  def trace(expr: Expr): String = ???

  def simplify(expr: Expr): Expr = ???

  val zeroAnd10 = Plus(Number(0), Number(10))
  println(trace(zeroAnd10)) // prints 0 + 10
  println(trace(simplify(zeroAnd10))) // prints 10

  println(trace(simplify(Min(zeroAnd10, zeroAnd10)))) // prints 10 - 10
}
