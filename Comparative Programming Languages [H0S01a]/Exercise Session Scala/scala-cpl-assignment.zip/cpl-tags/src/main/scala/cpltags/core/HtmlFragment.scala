package cpltags.core

trait HtmlFragment {
  def render: String
}

