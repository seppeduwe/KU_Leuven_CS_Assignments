package cpltags.dsl

// Definitions from: https://github.com/lihaoyi/scalatags/blob/master/scalatags/shared/src/main/scala/scalatags/text/Tags.scala

trait HtmlTags[T] {
  def tag(name: String): T

  // Root Element
  lazy val html = tag("html")

  // Document Metadata
  lazy val head = tag("head")

  // Scripting
  lazy val script = tag("script")

  // Sections
  lazy val body = tag("body")
  lazy val h1 = tag("h1")
  lazy val h2 = tag("h2")
  lazy val h3 = tag("h3")
  lazy val h4 = tag("h4")
  lazy val h5 = tag("h5")
  lazy val h6 = tag("h6")
  lazy val header = tag("header")
  lazy val footer = tag("footer")

  // Grouping content
  lazy val p = tag("p")
  lazy val pre = tag("pre")
  lazy val blockquote = tag("blockquote")
  lazy val ol = tag("ol")
  lazy val ul = tag("ul")
  lazy val li = tag("li")
  lazy val dl = tag("dl")
  lazy val dt = tag("dt")
  lazy val dd = tag("dd")
  lazy val figure = tag("figure")
  lazy val figcaption = tag("figcaption")
  lazy val div = tag("div")

  // Text-level semantics
  lazy val a = tag("a")
  lazy val em = tag("em")
  lazy val strong = tag("strong")
  lazy val small = tag("small")
  lazy val s = tag("s")
  lazy val cite = tag("cite")
  lazy val code = tag("code")
  lazy val sub = tag("sub")
  lazy val sup = tag("sup")
  lazy val i = tag("i")
  lazy val b = tag("b")
  lazy val u = tag("u")
  lazy val span = tag("span")

  // Edits
  lazy val ins = tag("ins")
  lazy val del = tag("del")

  // Embedded content
  lazy val iframe = tag("iframe")
  lazy val `object` = tag("object")
  lazy val video = tag("video")
  lazy val audio = tag("audio")
  lazy val canvas = tag("canvas")
  lazy val map = tag("map")

  // Tabular data
  lazy val table = tag("table")
  lazy val caption = tag("caption")
  lazy val colgroup = tag("colgroup")
  lazy val tbody = tag("tbody")
  lazy val thead = tag("thead")
  lazy val tfoot = tag("tfoot")
  lazy val tr = tag("tr")
  lazy val td = tag("td")
  lazy val th = tag("th")

  // Forms
  lazy val form = tag("form")
  lazy val fieldset = tag("fieldset")
  lazy val legend = tag("legend")
  lazy val label = tag("label")
  lazy val button = tag("button")
  lazy val select = tag("select")
  lazy val datalist = tag("datalist")
  lazy val optgroup = tag("optgroup")
  lazy val option = tag("option")
  lazy val textarea = tag("textarea")

  // Document Metadata
 lazy val title = tag("title")
 lazy val style = tag("style")

  // Scripting
 lazy val noscript = tag("noscript")

  // Sections
 lazy val section = tag("section")
 lazy val nav = tag("nav")
 lazy val article = tag("article")
 lazy val aside = tag("aside")
 lazy val address = tag("address")
 lazy val main = tag("main")

  // Text level semantics
 lazy val q = tag("q")
 lazy val dfn = tag("dfn")
 lazy val abbr = tag("abbr")
 lazy val data = tag("data")
 lazy val time = tag("time")
 lazy val `var` = tag("var")
 lazy val samp = tag("samp")
 lazy val kbd = tag("kbd")
 lazy val math = tag("math")
 lazy val mark = tag("mark")
 lazy val ruby = tag("ruby")
 lazy val rt = tag("rt")
 lazy val rp = tag("rp")
 lazy val bdi = tag("bdi")
 lazy val bdo = tag("bdo")

 lazy val output = tag("output")
 lazy val progress = tag("progress")
 lazy val meter = tag("meter")

  // Interactive elements
 lazy val details = tag("details")
 lazy val summary = tag("summary")
 lazy val menu = tag("menu")
}
