package cpltags.dsl

// Definitions from: https://github.com/lihaoyi/scalatags/blob/master/scalatags/shared/src/main/scala/scalatags/text/Tags.scala

trait HtmlEmptyTags[T] {
  def voidTag(name: String): T

  // Document Metadata
  lazy val base = voidTag("base")
  lazy val link = voidTag("link")
  lazy val meta = voidTag("meta")

  // Grouping content
  lazy val hr = voidTag("hr")
  lazy val br = voidTag("br")
  lazy val wbr = voidTag("wbr")

  // Embedded content
  lazy val img = voidTag("img")
  lazy val embed = voidTag("embed")
  lazy val param = voidTag("param")
  lazy val source = voidTag("source")
  lazy val track = voidTag("track")
  lazy val area = voidTag("area")

  // Tabular data
  lazy val col = voidTag("col")

  // Forms
  lazy val input = voidTag("input")

  // Forms
  lazy val keygen = voidTag("keygen")

  // Interactive elements
  lazy val command = voidTag("command")
}


