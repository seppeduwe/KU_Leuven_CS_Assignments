package cpltags.core

case class Attribute(key: String, value: String)

