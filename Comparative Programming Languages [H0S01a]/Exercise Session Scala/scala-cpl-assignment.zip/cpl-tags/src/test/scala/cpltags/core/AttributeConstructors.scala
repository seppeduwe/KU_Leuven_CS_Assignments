package cpltags.core

trait AttributeConstructors extends SimpleConstructors {

  // IMPLEMENT THE ???'s

  def newEmptyElement(tagName: String,
                      attributes: List[Attribute]): HtmlFragment = ???

  def newElement(tagName: String,
                 children: List[HtmlFragment],
                 attributes: List[Attribute]): HtmlFragment = ???

  def newAttribute(key: String, value: String): Attribute =
    new Attribute(key, value)

  override def newEmptyElement(tagName: String): HtmlFragment =
    newEmptyElement(tagName, Nil)

  override def newElement(tagName: String, children: List[HtmlFragment]): HtmlFragment =
    newElement(tagName, children, Nil)

}
