package cpltags.core

import org.scalatest.{ FunSpec, Matchers }

class HtmlFragmentTest extends FunSpec with Matchers with SimpleConstructors {
  val txt = text("text")
  val br = newEmptyElement("br")
  val emptyP = newElement("p", List.empty)

  describe("An HtmlFragment") {
    describe("when text") {
      it("should render as text") {
        txt.render shouldBe "text"
      }
    }

    describe("when empty") {
      it("should render as valid HTML") {
        br.render shouldBe "<br/>"
      }
    }

    describe("with 0 children") {
      it("should render as valid HTML") {
        emptyP.render shouldBe "<p></p>"
      }
    }

    describe("with 2 children") {
      val children = (1 to 2).map { n =>
        newElement("p", List(text(n.toString)))
      }.toList
      val divN = newElement("div", children)

      it("should render as valid HTML") {
        divN.render shouldBe "<div><p>1</p><p>2</p></div>"
      }
    }
  }

}
