package cpltags.dsl

import org.scalatest.{FunSpec, Matchers}

//class TagTest extends FunSpec with Matchers {
//
//  // YOU HAVE TO IMPORT YOUR DSL HERE:
//  //      import cpltags.dsl.All._
//  describe("A large example") {
//    it("should render properly") {
//
//      val fragment = html(
//        head(
//          script("some script")
//        ),
//        body(
//          h1("This is my title"),
//          br,
//          div(
//            p("onclick" := "... do some js")(
//              "This is my first paragraph"
//            ),
//            img("src" := "smiley.gif", "alt" := "smiley face"),
//            p("hidden" := "true")(
//              "I am hidden"
//            ),
//            input("type" := "text")
//          )
//        )
//      )
//
//      fragment.render shouldBe """<html><head><script>some script</script></head><body><h1>This is my title</h1><br/><div><p onclick="... do some js">This is my first paragraph</p><img src="smiley.gif" alt="smiley face"/><p hidden="true">I am hidden</p><input type="text"/></div></body></html>"""
//    }
//  }
//}
