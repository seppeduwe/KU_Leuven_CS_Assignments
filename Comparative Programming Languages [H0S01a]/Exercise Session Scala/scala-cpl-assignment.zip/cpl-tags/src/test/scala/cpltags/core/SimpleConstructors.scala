package cpltags.core

trait SimpleConstructors {

  // IMPLEMENT THE ???'s

  def text(content: String): HtmlFragment = ???
  def newEmptyElement(tagName: String): HtmlFragment = ???
  def newElement(tagName: String, children: List[HtmlFragment]): HtmlFragment = ???

}
