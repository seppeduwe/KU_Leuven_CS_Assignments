package cpltags.core

sealed trait HtmlFragment {
  def render: String
}

case class Text(render: String) extends HtmlFragment

sealed trait Element extends HtmlFragment {
  def name: String
  def attributes: List[Attribute]
  lazy val renderedAttributes =
    if (attributes.isEmpty) ""
    else " " + attributes.map(_.render).mkString(" ")
}

case class EmptyElement(name: String, attributes: List[Attribute])
    extends Element {
  val render: String = s"<$name$renderedAttributes/>"
}

case class ParentElement(name: String,
                         children: List[HtmlFragment],
                         attributes: List[Attribute])
    extends Element {
  val render: String = {
    val renderedChildren = children.map(_.render).mkString("")
    s"<$name$renderedAttributes>$renderedChildren</$name>"
  }
}
