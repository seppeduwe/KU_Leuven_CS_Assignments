package cpltags.dsl

import cpltags.core.{HtmlFragment, Text}

trait Implicits extends AttributeSyntax {
  import scala.language.implicitConversions

  implicit def liftStringToText(s: String): Text = Text(s)
}

object Implicits extends Implicits

