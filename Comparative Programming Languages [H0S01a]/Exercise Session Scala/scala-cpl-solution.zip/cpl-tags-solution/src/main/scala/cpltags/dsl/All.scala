package cpltags.dsl

object All
    extends HtmlTags[Tag]
    with HtmlEmptyTags[EmptyTag]
    with Implicits {
  def tag(name: String): Tag = new Tag(name)
  def voidTag(name: String): EmptyTag = new EmptyTag(name)
}
