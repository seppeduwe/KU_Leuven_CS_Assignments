package cpltags.dsl

import cpltags.core._

class EmptyTag(name: String) extends EmptyElement(name, Nil) {
  def apply(attributes: Attribute*): Element =
    apply(attributes.toList)

  def apply(attributes: List[Attribute]): Element =
    EmptyElement(name, attributes)
}
