package cpltags.dsl

import cpltags.core.{Attribute, Element, HtmlFragment, ParentElement}

class Tag(name: String) {
  def apply(children: HtmlFragment*): Element =
    ParentElement(name, children.toList, Nil)

  def apply(attributes: Attribute*)(children: HtmlFragment*): Element =
    ParentElement(name, children.toList, attributes.toList)
}
