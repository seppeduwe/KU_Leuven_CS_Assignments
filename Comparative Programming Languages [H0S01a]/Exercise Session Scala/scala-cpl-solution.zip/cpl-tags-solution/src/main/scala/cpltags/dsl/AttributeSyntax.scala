package cpltags.dsl

import cpltags.core.Attribute

trait AttributeSyntax {
  implicit class AttributeCreator(key: String) {
    def :=(value: String): Attribute = Attribute(key, value)
    def attr: Attribute = Attribute(key, "")
  }
}
