package cpltags.core

case class Attribute(key: String, value: String) {
  val render: String = s"""$key="$value""""
}
