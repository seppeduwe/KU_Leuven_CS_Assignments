package caseclasses

object PatternMatch extends App {
  abstract class Expr
  case class Number(num: Double) extends Expr
  case class Plus(left: Expr, right: Expr) extends Expr
  case class Min(left: Expr, right: Expr) extends Expr

  def trace(expr: Expr): String = expr match {
    case Plus(l, r) => s"${trace(l)} + ${trace(r)}"
    case Min(l, r) => s"${trace(l)} - ${trace(r)}"
    case Number(n) => n.toString
  }

  def simplify(expr: Expr): Expr = expr match {
    case Plus(Number(0), r) => simplify(r)
    case Plus(r, Number(0)) => simplify(r)
    case Min(r, Number(0)) => simplify(r)
    case Plus(l, r) => Plus(simplify(l), simplify(r))
    case Min(l, r) => Min(simplify(l), simplify(r))
    case r => r
  }

  val zeroAnd10 = Plus(Number(0), Number(10))
  println(trace(zeroAnd10)) // prints 0 + 10
  println(trace(simplify(zeroAnd10))) // prints 10

  println(trace(simplify(Min(zeroAnd10, zeroAnd10)))) // prints 10 - 10
}
