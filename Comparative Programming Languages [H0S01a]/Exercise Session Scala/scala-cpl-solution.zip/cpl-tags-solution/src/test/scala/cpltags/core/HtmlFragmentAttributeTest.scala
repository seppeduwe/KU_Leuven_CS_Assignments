package cpltags.core

import org.scalatest.{FunSpec, Matchers}

class HtmlFragmentAttributeTest
    extends FunSpec
    with Matchers
    with AttributeConstructors {

  val emptyP = newElement("p", List.empty, List.empty)

  describe("An HtmlFragment") {
    describe("when accepting attributes") {
      it("should render properly for 0 attributes") {
        emptyP.render shouldBe "<p></p>"
      }

      it("should render properly for 2 attributes") {
        val attrs = (1 to 2).map { n =>
          newAttribute(n.toString, n.toString)
        }.toList

        val divN = newElement("div", List.empty, attrs)

        divN.render shouldBe "<div 1=\"1\" 2=\"2\"></div>"
      }
    }
  }

}
