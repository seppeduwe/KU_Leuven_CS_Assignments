package cpltags.core

trait AttributeConstructors extends SimpleConstructors {

  def newAttribute(key: String, value: String): Attribute =
    new Attribute(key, value)

  def newEmptyElement(tagName: String,
                      attributes: List[Attribute]): HtmlFragment =
    new EmptyElement(tagName, attributes)

  def newElement(tagName: String,
                 children: List[HtmlFragment],
                 attributes: List[Attribute]): HtmlFragment =
    new ParentElement(tagName, children, attributes)





  override def newEmptyElement(tagName: String): HtmlFragment =
    newEmptyElement(tagName, Nil)

  override def newElement(tagName: String, children: List[HtmlFragment]): HtmlFragment =
    newElement(tagName, children, Nil)

}
