package cpltags.core

trait SimpleConstructors {

  def text(content: String): HtmlFragment =
    new Text(content)
  def newEmptyElement(tagName: String): HtmlFragment =
    new EmptyElement(tagName, Nil)
  def newElement(tagName: String, children: List[HtmlFragment]): HtmlFragment =
    new ParentElement(tagName, children, Nil)

}
